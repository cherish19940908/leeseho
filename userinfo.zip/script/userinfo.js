function pwpw(){
var reg = /^(?=.*?[A-Z])(?=.*?[a-z])(?=.*?[0-9])(?=.*?[#?!@$%^&*-]).{8,}$/;
var password = join.phone.value
 
if(false === reg.test(password)) {
    alert('Please enter your mobile number correctly.');
}
}